//IPVersion.h
#pragma once

namespace PNet
{
	enum IPVersion
	{
		Unknown,
		IPv4,
		IPv6
	};
}