//Constants.h
#pragma once

namespace PNet
{
	const int g_MaxPacketSize = 8192;
}